from pathlib import Path
import json,csv,math,hashlib
R=Path(__file__).resolve().parent;p=json.loads((R/'parameters.json').read_text())
g=9.81;Fz=p['total_mass_kg']*g*p['max_wheel_fraction']*p['dynamic_factor'];Fy=p['guide_lateral_force_N'];L=p['roller_width']+20
stress=32*(Fy*L/4)/(math.pi*9.85**3)
report=f'''# QS212 레일 주행 모듈 R01 — 설계 및 조립 검토서

**제작 승인/탑승 승인 도면이 아닙니다.** 단일 바퀴 모듈의 조립·가공 방법과 형상 검토용 수정 가능한 초안입니다. 현장 레일·OEM 모터 치수·연결부 정격·제동 검증 후 상세 설계를 확정해야 합니다.

## 1. 입력 자료와 치수 신뢰도

- 사용자 첨부 `QS212_1200W_tire_reference.step`: 실제 불러오기 및 형상 유효성 검사. 과거 생성한 추정 모델이며 OEM 제조사 원본이 아님. SHA256 `{hashlib.sha256((R/'reference/QS212_1200W_tire_reference.step').read_bytes()).hexdigest()}`.
- 축 길이270, 장착 외측면 간격200.5, 축Ø16/평면폭12, 림 외경279/폭73은 **입력 STEP/저해상도 도면 기준값**. OEM 주문품에서 보증되지 않음. 축M16x1.5도 실측/공급사 확인 필요.
- 타이어3.00-10, 외경406.4, 폭76.2는 **임시 가정**. 실제 타이어 무부하 외경·하중변형·하중등급·타이어 회전 외형으로 교체할 것.
- `3DP_20544_S-0037.stl`은 첨부 전송32MiB 제한 때문에 읽지 못함. Thingiverse4498730의 원본/파일목록/ZIP은403. STL을 임의 변환했다고 주장하지 않음. 사용자 후속 지시에 따라 아래 PDF를 대체 근거로 사용.
- 사용자 PDF `KRS TR0001-15(R) 레일`, **부도3 60K, PDF19쪽/인쇄18/20쪽**: 머리폭65, 높이174, 바닥폭145, 웹16.5, 두부높이49, 측면기울기1:40을 확인. 문서상 60K와 현장 레일을 동일시하지 않음.
- R00 레일 CAD는 위 주요 치수·R300 상면·1:40 측면을 반영한 **매개변수 단면 외피**. R13/R5/R18/R500 등의 전체 접선 원호와 마모·캔트·체결구는 완전 복원하지 않음. 정확한 표준 단면 제조 CAD로 교체 필요. 1435 궤간은 단일 레일 머리 폭을 정하는 값이 아님.

## 2. 좌표와 부품 분리

X=레일 길이(앞뒤), Y=좌우(모터 고정축 방향), Z=수직. 레일 두부 최고점 Z=0, 바퀴 중심 (0,0,203.2)mm. 기본 모델은 타이어 무변형/레일무캔트 조건.

- M01 타이어와 M02 모터 외통은 회전 그룹. M03 축, A01/A02, 프로파일은 고정 그룹.
- 모터 외통/타이어에는 추가 구멍이나 가이드 체결부가 전혀 없음.
- 전후 가이드 중심 X=±220. 각 위치 Y 양쪽에 롤러, 총4개. 롤러 축은 Z방향.
- 프로파일 프레임580×308mm 외곽(가셋/체결물 돌출은 별도 외피 확인), 상부 프로파일 하단Z430. 타이어 위쪽 여유23.6mm(입력타이어 기준). 가이드축은 바퀴 최외곽X±203.2보다 바깥17mm에 놓음; 브라켓의 일부가 X190까지 오더라도 그 높이의 타이어 단면과 별도 간섭검사를 수행.

## 3. 축 고정판과 회전 방지

A01: S355 10mm,220×170mm 후보. 모터 양측 고정판 **외측면**을Y=±100.25로 둠. 내측면은±90.25. 실제 제조사 OLD 정의(내측 장착면인지 외측인지)를 확인해 `mount_outer_span`과 판 위치를 수정할 것. 이것은200.5를 OEM OLD로 확정한 것이 아님.

하향 개방 슬롯폭16.2, 상부 평면 Z=축중심+6.1. A02 인보드 분리형 키퍼60×약23.9×10mm가 아래 평면을 받음. 축의 양면 평면으로 모터 반력 토크를 전달하고, 키퍼는2×M8×20(8.8급)로 고정. **축 너트 마찰만으로 토크를 지지하지 않는다.** 평면 모서리의 국부 접촉/피로와 키퍼 볼트 전단·슬롯 벌어짐 검증 필요. 모터 축이나 외통을 새로 절삭하라는 설계가 아님.

A01 바깥에 OEM 경화와셔 t3와 M16너트 높이13을 배치. 입력 모델 기준 축 한쪽 끝까지 남는 길이18.75mm. 너트 유효 나사맞물림13mm는 **나사 시작/끝이 확인될 때만** 성립. 실제 나사 유효길이·런아웃·와셔두께·토크를 공급사 도면으로 확인. 너트는 모터 제조사 지정품/토크로 체결. 여기서 임의 토크값을 지정하지 않음.

프로파일 내측면Y±114와 고정판 사이 명목13.75mm 스페이서 OD20/ID9 사용. 고정판당6×M8×35(8.8)+와셔+HFS8용 M8 T너트. 축키퍼보다 바깥에서 스패너로 축너트에 접근 가능. M16 소켓 외경/연장봉 접근은 실제공구로 확인.

**케이블/브레이크 공간**: 케이블측은 임시+Y로 지정. 축 끝 바깥Y125~205, X±25, 축높이-60~+30mm를 케이블 여유 상자로 예약. 케이블은 너트/평면슬롯에 끼우지 않고 실물 OEM 인출구와 최소굽힘반경 확인 후 루팅. -Y측 허브~고정판 사이에 브레이크 로터 외피(예:Ø150,t2,Y-74~-72)와 별도 캘리퍼 어댑터 공간을 검토할 수 있으나, **홀 PCD·로터·캘리퍼는 미선정이며 STEP에 미장착**. 양쪽 축너트나 키퍼와의 공구 여유도 재확인.

## 4. 레일 가이드의 실제 접촉과 조절

롤러는 주문제작안: OD50,폭28,약0.5mm 반경 크라운의 PU ShoreA90 +6061-T6 코어OD42. 베어링2×6002DDU(15×32×9), 안쪽 스페이서10, 상하 스페이서각10. 스페이서는 베어링 **내륜에만** 닿는 OD21. 코어 중앙턱 ID24, 양쪽Ø32 좌대9mm. 좌대 끼워맞춤·끝단 축방향 유지(억지끼움+승인접착/별도유지)·내륜길이 공차를 공급사와 확정. 구매 대체롤러는 외경/폭/베어링/허용횡하중/회전수를 확인하고 파라미터 변경 후 재생성.

수직스핀들Ø15(베어링 구간48mm), 양끝M12x1.75×38 축소나사. S45C/C45 후보, 베어링좌 j6/g6 선택은 베어링하중방향/설치공차 검토 후 확정. 반경/런아웃과 나사끝단 필렛 가공. 베어링 아래에 나사산이 오지 않게 함.

G07: 하부8mm 수평판+12mm 수직벽 S355 용접물. G08 상부8mm 분리판은2×M6×25로벽에 체결, 위에서 분해 가능. 벽은**3×M8×25**로 가이드 수직 프로파일 내측T슬롯에 체결(모든볼트 X=가이드스테이션, Z=-40,-24,-8). 벽의 볼트를 X±18에 놓으면 T슬롯과 안 맞으므로 사용하지 않음.

상하판에는Y방향13×25장공(중심이동±6), Ø15스핀들의 축소M12 나사끝이 통과. 상하40×40×12슬라이딩 클램프판/와셔/풀림방지너트로 고정. 상부벽의M8 잭스크루로 외측에서 위치를 미세조정하고 잼너트로 잠금. 한쪽면의 잭스크루는 밀기 전용이므로 안쪽으로 조절할 때 너트를 풀고 수동으로 복귀시킨다. 상하축이 평행·수직을 유지하도록 두장공 위치를 같이 확인한 후 체결.

60K 머리 측면은1:40. 크라운이 없는 직각 원통형 롤러로 면전체가 접촉한다고 가정하지 않음. 현재 크라운/기울기에서 명목 최소간극은1mm/면, 접촉예상높이는약Z=-24.9mm. 이는 레일머리의 옆면이며 윗면이 아님. 무횡하중일 때1mm떠 있는 것은 **설계 간극**이다. 한쪽으로1mm움직이면 그쪽롤러가 접촉하고 반대쪽은약2mm간극. `Contact_detail` 도면에 무하중/편측접촉 위치를 같이 표시.

크라운 PU의 변형·마모에 따라 접촉패치/최소간극이 달라짐. 네롤러를 레일에 예압으로 꽉물리지 말 것. 모터에토크를 주지않은 상태에서 손으로 전구간 왕복 확인 후 설정. ±6mm조절은 좌우위치 보정범위이며 레일 모든형상을자동추종하는 범위가 아님.

## 5. 하중 전달과 초기 계산

가이드기둥과 축지지기둥 사이 X방향 보강보4개(L95,4040)를 Z110~150에 추가하고, 양단에 S355t6 연결판8개/총32M8볼트로 고정. 가이드접촉 높이에서 낮은 보강보 중심까지의 지간은 약150mm. 상부까지450mm이상 단독외팔보로 쓰지 않는 구조. 접속부 강성은 실제 조인트시험/해석 필요.


사용자 선택 총중량200kg(사람+차체+배터리 포함), 바퀴4개. 평균정하중490.5N/바퀴. 검토용 최대분담률40%, 동하중계수2.0이면 한모듈 설계수직하중 **{Fz:.1f}N**. 200kg을 각바퀴에 반복 적용한 것이 아님. 축 양측 균등분담도 현장에서는 보장되지 않음.

횡하중은 별도 가정: **가이드 롤러1개에{Fy:.0f}N**. 네롤러 균등분담으로 나누지 않음. 이는 곡선/이음매 충격에서 산정된 값이 아니며 실제시험으로갱신해야함. 모터반력토크100N·m는강도검토용가정이며연속정격토크가아님.

하중경로: 레일옆면→PU외주/코어→베어링외륜→전동체/내륜→스페이서/스핀들→상하요크→수직벽→M8볼트/T너트→수직프로파일→상부앵글/보강판→낮은 보강보/연결판 및 상부프레임→차체연결부. 차체에고정하는상위접속부는 이번단일모듈범위외로 정격검토필요.

단순스핀들계산(양단지지,지간{L:.0f}mm,중앙집중하중500N) 최대굽힘모멘트{Fy*L/4:.0f}Nmm. M12나사골Ø9.85에 전부작용한다고보면 공칭굽힘응력약{stress:.1f}MPa(응력집중·피로·유격미포함). 6002DDU 제조사정격Cr6150N/C0r2840N은 베어링단품자료일뿐 PU/축/용접/프로파일접속의허용하중이아님. 20km/h에서Ø50롤러는약2122rpm; 발열·PU허용속도·베어링씰마찰검증필요.

**질량예산주의**: 이초안은 견고한시험모듈형태로, 장프로파일/철판/모터까지모듈4개로구성하면차량자중비중이커질수있음. 동봉질량예산은수량/외피체적기반의예비치. 사람2~3명포함200kg이성립하는지는 실물부품질량과총차체질량으로다시계산. 본설계로200kg탑승가능을단정하지않음.

## 6. 측면 안내와 들림 방지 / 운전 범위

네개의수직축롤러는좌우안내기능이며 **수직들림을구속하지않는다**. 레일머리아래로걸리는별도의안티리프트장치·갭·하중/분기기간섭검토가필요하며 이R01주조립에는미장착. 이조건때문에탑승/20km/h운행승인이아니다. 양쪽레일의하중분배/프레임비틀림/서스펜션도차량전체검토항목.

직선의통제시험궤도만대상. 곡선에서전후가이드구속·공격각·좌우속도차,캔트/완화곡선,분기기/크로싱의가이드단절,이음매/체결구와의간섭은 추가검토. 기계식운행제동/주차제동·비상정지·통신상실시제동은차량필수별도설계. 철도운영기관의선로통제/허가조건은별도충족필요.

## 7. 조립 순서

1. 레일단면, OEM축flat/나사/OLD,실제타이어외경·폭·하중등급측정. parameters.json수정후재생성. 레일체결구포함현장단면확인.
2. 주문가공판/요크디버링,축좌가공면과용접뒤틀림검사. 프로파일절단면직각확인. 홈시리즈혼용금지.
3. 상부장보2개+가로보2개를앵글/상부보강판으로가조립.8개수직재를앵글로연결. 볼트위치와T너트방향확인.
4. 양쪽A01을6개스페이서+M8/T너트로가조립. 입력모터축을하향개방슬롯에삽입하고,인보드A02키퍼2×M8체결. 축양면flat방향맞춤.
5. 모터OEM와셔/너트체결. 케이블을누르지않고인출. 타이어수동회전과브레이크공간확인. 모터외통에임의구멍가공금지.
6. 하부요크를3×M8/T너트로가이드기둥에장착. 하부축소M12끝을하부장공에넣음. 스페이서→베어링/롤러코어/내륜스페이서→스페이서순으로스핀들에조립.
7. 상부분리판을스핀들위에씌우고2×M6로벽에체결. 상하클램프판/와셔/M12잠금너트조립. 양베어링외륜을축너트로직접압착하지말것.
8. 레일에바퀴를안착. 잭스크루로양쪽간극1mm기준을설정(실제레일마모/기울기에따라조정). 상하클램프·잼너트잠금. 네위치높이/수직도확인.
9. 무부하수동왕복→외부견인저속무인시험→단계하중시험. 체결풀림표식,롤러온도·마모,프로파일접속변위측정. 탑승/20km/h로바로진입하지않음.

## 8. 파일과 편집

- cad/Module_assembly.step: 이름있는부품별조립. Fusion360에서열수있는B-rep형식. STEP자체에는원래의파라미터/피처타임라인이없음.
- build_module.py + parameters.json: 실제실행/검증한CadQuery원본. 치수변경후이스크립트를재실행하여STEP/부품을갱신.
- fusion360/QS212_Rail_Module.py +동일폴더JSON2개: Fusion의스크립트에서실행하면네이티브컴포넌트/치수스케치/돌출·회전피처를생성하는코드. **클라우드에Fusion이없어실행검증하지못함.** 생성후.f3d로저장가능.슬롯치수/부호가바뀌는대규모변경은스크립트재실행필요. 기본표준체결품은처리속도를위해숨김/생략가능.
- drawings: 정면(YZ)/측면(XZ)/평면(XY),분해도,접촉확대,가공도초안PDF/PNG,판재DXF.
- reports/interference_checks.json: 명시한쌍의실체교차/최단거리. 볼트-구멍/베어링-축등의설계접촉은별도구분. **전체차량·가공공차·하중변형·스패너스윕·브레이크완성품·현장체결구전체간섭검증은아님.**

## 9. 조달 근거와 미확정품

공개상품페이지는후보계열과치수존재를확인하는근거이며재고/견적/강도인증을보장하지않음.
- MISUMI HFS8-4040/홈폭10 8시리즈 프레임. 8mm홈경제형4040과혼동금지: https://kr.misumi-ec.com/pdf/fa/2015/p2_0671.pdf
- HBLFSN8-SEU 브래킷계열: https://kr.misumi-ec.com/vona2/detail/110300449520/?HissuCode=HBLFSN8-SEU
- HFS8 M8 T너트: 선택한정품프레임의적용표로형번/높이확정, CAD는외피만표현.
- NSK6002DDU,15×32×9,Cr6150N/C0r2840N: https://www.nsk.com/kr-ko/engineering/products/bearings/ball-bearings/deep-groove-ball-bearings/6002ddu-dgbb-sr.html
- 구매롤러대체후보MISUMI경제형PU베어링롤러: https://kr.misumi-ec.com/vona2/detail/110310365039/ . 본설계50×28크라운롤러와동일하지않으며주문형/대체후수정필요.

## 10. 제작 전 해제해야 하는 보류점

OEM축/타이어도면,현장레일단면·마모·캔트·체결구,PU롤러하중/속도등급,프로파일/브래킷접속허용하중과미끄럼,키퍼/축평면국부응력·피로,나사맞물림,용접상세,기계식제동과안티리프트,전체차량하중분배·질량. 미확정항목이남아있으므로가공도는**초안**이다.
'''
(R/'DESIGN_REVIEW_KO.md').write_text(report)
# Consolidated manufacturing/purchase BOM, quantities per one module.
rows=[
('QS212 motor','purchase',1,'1200W input-model reference','OEM exact variant/axle/cable/brake drawing required'),
('3.00-10 tire','purchase',1,'OD406.4 W76.2 assumed','actual inflated size and load rating required'),
('HFS8-4040 long beam','purchase-cut',2,'L580, slot10 series8','supplier CAD; 6063/6005 family'),
('HFS8-4040 motor post','purchase-cut',4,'L320','fromZ110to430'),
('HFS8-4040 guide post','purchase-cut',4,'L482','no mixing8mm slot hardware'),
('HFS8-4040 crossbeam','purchase-cut',2,'L228','top flush to longbeam'),
('Low bridge 4040','purchase-cut',4,'L95,Z110to150','F06; connects guidepost to motorpost'),
('Low bridge gusset','custom',8,'S355t6,95x80,4xD9','F07; outer side faces'),
('Low bridge bolts+washers+Tnuts','purchase',32,'M8x20+1.6washer+2shim+M8Tnut','verify exact supplier Tnut engagement'),
('40series angle','purchase',8,'HBLFSN8 family envelope','catalogue exact hole geometry confirmation'),
('Top splice plate','custom',4,'S355 40x80x6,2xD9 pitch40','F05'),
('Axle support plate','custom',2,'S355 t10,220x170, open notch16.2','A01; exact axle fit pending'),
('Axle torque keeper','custom',2,'S355 t10,2xM8 tap','A02; remove to lower wheel'),
('Plate spacers','custom',12,'OD20 ID9 L13.75','equal lengths; update with actual OLD'),
('Guide lower yoke','custom-weld',4,'wall12 arm8;4mm fillet weld draft','G07;3M8 on centre T slot'),
('Guide top arm','custom-weld',4,'arm8+jack lug,2M6 through','G08; removable'),
('Crowned PU roller tread','custom',4,'OD50 W28,crown0.5radial,ShoreA90','bonded to core; rating unverified'),
('Roller core','custom',4,'6061-T6 OD42,2xD32 seats','bearing retention fit pending'),
('6002DDU bearing','purchase',8,'15x32x9','NSK catalogue link in report'),
('Inner bearing spacer','custom',4,'OD21 ID15.2 L10','inner rings only'),
('End bearing spacer','custom',8,'OD21 ID15.2 L10','inner rings only'),
('Guide spindle','custom',4,'C45 D15x48,2xM12x1.75 L38 ends','shaft total124; fillets/threadrunout pending'),
('Sliding clamp block','custom',8,'S355 40x40x12,D13','top and bottom of slot'),
('M12 prevailing torque nut','purchase',8,'M12x1.75','plus8 hardened washers2.5thick'),
('M8 jack screw + jam nut','purchase',4,'M8x40, class8.8','push-only; movement+-6'),
('OEM axle nut+washer','purchase',2,'M16x1.5 nut13 + hardened washer3 assumed','MUST confirm OEM'),
('M8x35+washer+T nut','purchase',12,'class8.8; axle plate to post','6 per side'),
('M8x20 keeper screws','purchase',4,'class8.8; into keeper M8','2 per side'),
('M8x25+washer+T nut','purchase',12,'class8.8; guide yoke to post','3 per yoke'),
('M6x25+washer','purchase',8,'class8.8; removable top arm','2 per yoke'),
('M8x16+washer+T nut','purchase',16,'class8.8;8 catalogue angles','2 per angle'),
('M8x20+washer+T nut','purchase',8,'class8.8; top splice plates','2 per splice'),
('Brake/anti-lift','NOT_SELECTED',0,'required vehicle safety subsystems','not included in main module CAD'),
]
with (R/'BOM_consolidated.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f);w.writerow(['item','type','qty_per_module','specification_draft','notes']);w.writerows(rows)
with (R/'FASTENER_CONNECTIONS.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f);w.writerow(['connection','qty','bolt','entry_face','target','note'])
 w.writerows([
 ('A01 to motor posts',12,'M8x35+washer','plate INBOARD face, axis outward Y','M8 HFS8 Tnut at post inner face','plate10+spacer13.75+washer1.6; confirm nut body'),
 ('A02 keeper to A01',4,'M8x20+washer','plate OUTBOARD face, axis inward Y','keeper M8 through tap','10mmplate+1.6washer gives8.4mm thread engagement'),
 ('G07 to guide post',12,'M8x25+washer','yoke inner wall face, axis outward Y','M8 Tnut','X=+-220; Z=-40,-24,-8'),
 ('Low gussets to posts/bridges',32,'M8x20+washer1.6+shim2','gusset OUTBOARD face, axis inward Y','profile outer Tslot M8nut','4 per gusset; no bolt into extrusion wall'),
 ('G08 top arm to G07',8,'M6x25+washer','top arm TOP face, axis-Z','wall M6 tap','X=station+-20; nominal15.4engagement'),
 ('Spindle upper/lower clamp',8,'M12 locknut+2.5washer','above/below clamp blocks','reduced shaft threads','bearing preload through inner ring spacers; no outer ring clamp'),
 ('Upper column angles',16,'M8x16+washer','angle exposed face','profile M8 Tnut','vendor angle exact hole positions TBD'),
 ('Top splice straps',8,'M8x20+washer','strap top face, axis-Z','profile M8 Tnut','strap6+washer1.6'),
 ('Jack adjustment',4,'M8x40+jamnut','OUTER side of jack lug, axis toward rail','M8 tapped lug against upper clamp','do not use it as sole guide structural retention'),
 ('OEM axle nut',2,'OEMM16x1.5 assumed','outside both plates','OEM axle end thread','OEM torque only; threadstart/end TBD'),
 ])
print('Documentation and consolidated BOM written.')
